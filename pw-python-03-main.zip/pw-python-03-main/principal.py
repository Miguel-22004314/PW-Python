import calculos

if __name__ == '__main__':
    calculos.calcula_ocorrencia_de_letras()